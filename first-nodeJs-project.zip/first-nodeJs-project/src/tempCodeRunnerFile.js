 3000;
const path = require('path');
const hbs = require('hbs')

const staticpath = path.join(__dirname , '../public')
const staticpath2 = path.joi